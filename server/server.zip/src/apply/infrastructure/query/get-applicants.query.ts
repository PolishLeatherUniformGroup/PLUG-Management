import { IQuery } from '@nestjs/cqrs';

export class GetApplicantsQuery implements IQuery {}
