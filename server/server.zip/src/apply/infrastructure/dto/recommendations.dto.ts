import { RecommendationDto } from './recommendation.dto';

export class RecommendationsDto {
  public data: RecommendationDto[];
}
