import { ApplicantDto } from './applicant.dto';

export class ApplicantsDto {
  public data: ApplicantDto[];
}
