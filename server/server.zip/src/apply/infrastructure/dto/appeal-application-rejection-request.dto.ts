export class AppealApplicationRejectionRequestDto {
  id: string;
  justification: string;
  appealDate: Date;
}
