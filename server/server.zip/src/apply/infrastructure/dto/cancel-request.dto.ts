export class CancelRequestDto {
  applicantId: string;
}
