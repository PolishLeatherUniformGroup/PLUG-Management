import { ApplicationReceivedHandler } from "./application-received.handler";

export * from './application-received.handler'

export const EventHandlers = [
    ApplicationReceivedHandler
];