import { MigrationInterface, QueryRunner } from "typeorm";

export class Init1707776935444 implements MigrationInterface {

    public async up(queryRunner: QueryRunner): Promise<void> {
    }

    public async down(queryRunner: QueryRunner): Promise<void> {
    }

}
