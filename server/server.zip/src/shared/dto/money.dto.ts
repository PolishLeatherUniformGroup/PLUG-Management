export class MoneyDto {
  amount: number;
  currency: string;
}
