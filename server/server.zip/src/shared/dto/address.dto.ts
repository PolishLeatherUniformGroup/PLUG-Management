export class AddressDto {
  country: string;
  city: string;
  street: string;
  postalCode: string;
  state?: string;
}
