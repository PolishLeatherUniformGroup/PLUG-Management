export enum MemberStatus {
  Active = 1,
  Suspended,
  Expelled,
  Expired,
  Cancelled,
  Deleted,
}
