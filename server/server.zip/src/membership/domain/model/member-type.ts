export enum MemberType {
  Regular = 1,
  Honorary = 2,
}
