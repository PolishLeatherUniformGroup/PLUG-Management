export class MemberHistory {}
