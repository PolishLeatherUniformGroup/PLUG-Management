import { IQuery } from '@nestjs/cqrs';

export class GetActiveMembersQuery implements IQuery {
  constructor() {}
}
