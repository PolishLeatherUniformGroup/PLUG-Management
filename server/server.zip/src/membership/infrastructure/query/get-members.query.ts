import { IQuery } from "@nestjs/cqrs";

export class GetMembersQuery implements IQuery {
  constructor(){}
}