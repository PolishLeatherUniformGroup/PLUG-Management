import { MembershipFeeDto } from "./membership-fee.dto";

export class MembershipFeesDto {
    data: MembershipFeeDto[];
}