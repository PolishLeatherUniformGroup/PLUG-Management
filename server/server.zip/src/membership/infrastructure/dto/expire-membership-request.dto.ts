export class ExpireMembershipRequestDto {
  public memberId: string;
  public date: Date;
}
