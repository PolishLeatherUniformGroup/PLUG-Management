import { MemberDto } from './member.dto';

export class MembersDto {
  data: MemberDto[];
}
