export class MakeMemberHonoraryRequestDto {
  public memberId: string;
}
