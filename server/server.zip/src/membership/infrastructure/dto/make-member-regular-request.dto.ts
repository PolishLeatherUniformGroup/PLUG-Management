export class MakeMemberRegularRequestDto {
  public memberId: string;
}
