export class CancelMembershipRequestDto {
  public memberId: string;
  public date: Date;
}
