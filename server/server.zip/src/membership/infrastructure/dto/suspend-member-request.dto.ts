export class SuspendMemberRequestDto {
  public memberId: string;
  public date: Date;
  public reason: string;
  public suspendedUntil: Date;
}
