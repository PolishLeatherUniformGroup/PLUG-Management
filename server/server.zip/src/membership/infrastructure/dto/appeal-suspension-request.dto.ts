export class AppealSuspensionRequestDto {
  public memberId: string;
  public suspensionId: string;
  public date: Date;
  public justification: string;
}
