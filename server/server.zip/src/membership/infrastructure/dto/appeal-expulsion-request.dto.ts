export class AppealExpulsionRequestDto {
  public memberId: string;
  public expulsionId: string;
  public date: Date;
  public justification: string;
}
