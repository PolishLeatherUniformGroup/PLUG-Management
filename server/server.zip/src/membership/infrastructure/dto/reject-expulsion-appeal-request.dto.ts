export class RejectExpulsionAppealRequestDto {
  public memberId: string;
  public expulsionId: string;
  public decision: string;
  public date: Date;
}
