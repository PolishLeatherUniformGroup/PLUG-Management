export class AcceptSuspensionAppealRequestDto {
  public memberId: string;
  public suspensionId: string;
  public decision: string;
  public date: Date;
}
