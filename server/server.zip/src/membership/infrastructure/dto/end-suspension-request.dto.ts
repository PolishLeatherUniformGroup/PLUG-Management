export class EndSuspensionRequestDto {
  public memberId: string;
}
