export class AcceptExpulsionAppealRequestDto {
  public memberId: string;
  public expulsion: string;
  public decision: string;
  public date: Date;
}
