export class ExpelMemberRequestDto {
  public memberId: string;
  public date: Date;
  public reason: string;
}
