import { ApplicantAcceptedHandler } from './applicant-accepted.handler';
export * from './applicant-accepted.handler';
export const Notifications = [ApplicantAcceptedHandler];
